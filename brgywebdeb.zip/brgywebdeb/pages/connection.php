<?php		
			// Establishing Connection with Server by passing inputs as a parameter



 $con = mysqli_connect('localhost','root','','db_barangay') or die(mysqli_error());



			date_default_timezone_set("Asia/Manila");


?>